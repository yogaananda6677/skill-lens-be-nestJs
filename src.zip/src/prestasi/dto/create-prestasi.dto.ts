export class CreatePrestasiDto {}
