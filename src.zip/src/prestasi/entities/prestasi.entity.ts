export class Prestasi {}
