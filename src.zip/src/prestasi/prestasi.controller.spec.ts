import { Test, TestingModule } from '@nestjs/testing';
import { PrestasiController } from './prestasi.controller';
import { PrestasiService } from './prestasi.service';

describe('PrestasiController', () => {
  let controller: PrestasiController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PrestasiController],
      providers: [PrestasiService],
    }).compile();

    controller = module.get<PrestasiController>(PrestasiController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
