import { Test, TestingModule } from '@nestjs/testing';
import { PrestasiService } from './prestasi.service';

describe('PrestasiService', () => {
  let service: PrestasiService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PrestasiService],
    }).compile();

    service = module.get<PrestasiService>(PrestasiService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
