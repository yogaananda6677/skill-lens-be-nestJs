import { Injectable } from '@nestjs/common';
import { CreatePrestasiDto } from './dto/create-prestasi.dto';
import { UpdatePrestasiDto } from './dto/update-prestasi.dto';

@Injectable()
export class PrestasiService {
  create(createPrestasiDto: CreatePrestasiDto) {
    return 'This action adds a new prestasi';
  }

  findAll() {
    return `This action returns all prestasi`;
  }

  findOne(id: number) {
    return `This action returns a #${id} prestasi`;
  }

  update(id: number, updatePrestasiDto: UpdatePrestasiDto) {
    return `This action updates a #${id} prestasi`;
  }

  remove(id: number) {
    return `This action removes a #${id} prestasi`;
  }
}
