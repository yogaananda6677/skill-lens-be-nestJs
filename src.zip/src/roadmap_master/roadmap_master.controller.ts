import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { RoadmapMasterService } from './roadmap_master.service';
import { CreateRoadmapMasterDto } from './dto/create-roadmap_master.dto';
import { UpdateRoadmapMasterDto } from './dto/update-roadmap_master.dto';

@Controller('roadmap-master')
export class RoadmapMasterController {
  constructor(private readonly roadmapMasterService: RoadmapMasterService) {}

  @Post()
  create(@Body() createRoadmapMasterDto: CreateRoadmapMasterDto) {
    return this.roadmapMasterService.create(createRoadmapMasterDto);
  }

  @Get()
  findAll() {
    return this.roadmapMasterService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.roadmapMasterService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateRoadmapMasterDto: UpdateRoadmapMasterDto) {
    return this.roadmapMasterService.update(+id, updateRoadmapMasterDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.roadmapMasterService.remove(+id);
  }
}
