import { Module } from '@nestjs/common';
import { RoadmapMasterService } from './roadmap_master.service';
import { RoadmapMasterController } from './roadmap_master.controller';

@Module({
  controllers: [RoadmapMasterController],
  providers: [RoadmapMasterService],
})
export class RoadmapMasterModule {}
