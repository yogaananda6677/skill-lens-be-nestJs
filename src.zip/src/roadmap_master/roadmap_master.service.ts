import { Injectable } from '@nestjs/common';
import { CreateRoadmapMasterDto } from './dto/create-roadmap_master.dto';
import { UpdateRoadmapMasterDto } from './dto/update-roadmap_master.dto';

@Injectable()
export class RoadmapMasterService {
  create(createRoadmapMasterDto: CreateRoadmapMasterDto) {
    return 'This action adds a new roadmapMaster';
  }

  findAll() {
    return `This action returns all roadmapMaster`;
  }

  findOne(id: number) {
    return `This action returns a #${id} roadmapMaster`;
  }

  update(id: number, updateRoadmapMasterDto: UpdateRoadmapMasterDto) {
    return `This action updates a #${id} roadmapMaster`;
  }

  remove(id: number) {
    return `This action removes a #${id} roadmapMaster`;
  }
}
