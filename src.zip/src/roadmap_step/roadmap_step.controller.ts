import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { RoadmapStepService } from './roadmap_step.service';
import { CreateRoadmapStepDto } from './dto/create-roadmap_step.dto';
import { UpdateRoadmapStepDto } from './dto/update-roadmap_step.dto';

@Controller('roadmap-step')
export class RoadmapStepController {
  constructor(private readonly roadmapStepService: RoadmapStepService) {}

  @Post()
  create(@Body() createRoadmapStepDto: CreateRoadmapStepDto) {
    return this.roadmapStepService.create(createRoadmapStepDto);
  }

  @Get()
  findAll() {
    return this.roadmapStepService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.roadmapStepService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateRoadmapStepDto: UpdateRoadmapStepDto) {
    return this.roadmapStepService.update(+id, updateRoadmapStepDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.roadmapStepService.remove(+id);
  }
}
