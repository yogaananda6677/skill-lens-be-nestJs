import { Module } from '@nestjs/common';
import { RoadmapStepService } from './roadmap_step.service';
import { RoadmapStepController } from './roadmap_step.controller';

@Module({
  controllers: [RoadmapStepController],
  providers: [RoadmapStepService],
})
export class RoadmapStepModule {}
