import { Injectable } from '@nestjs/common';
import { CreateRoadmapStepDto } from './dto/create-roadmap_step.dto';
import { UpdateRoadmapStepDto } from './dto/update-roadmap_step.dto';

@Injectable()
export class RoadmapStepService {
  create(createRoadmapStepDto: CreateRoadmapStepDto) {
    return 'This action adds a new roadmapStep';
  }

  findAll() {
    return `This action returns all roadmapStep`;
  }

  findOne(id: number) {
    return `This action returns a #${id} roadmapStep`;
  }

  update(id: number, updateRoadmapStepDto: UpdateRoadmapStepDto) {
    return `This action updates a #${id} roadmapStep`;
  }

  remove(id: number) {
    return `This action removes a #${id} roadmapStep`;
  }
}
