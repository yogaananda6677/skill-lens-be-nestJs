export class CreateRoadmapStepDetailDto {}
