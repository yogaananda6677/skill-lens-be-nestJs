import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { RoadmapStepDetailService } from './roadmap_step_detail.service';
import { CreateRoadmapStepDetailDto } from './dto/create-roadmap_step_detail.dto';
import { UpdateRoadmapStepDetailDto } from './dto/update-roadmap_step_detail.dto';

@Controller('roadmap-step-detail')
export class RoadmapStepDetailController {
  constructor(private readonly roadmapStepDetailService: RoadmapStepDetailService) {}

  @Post()
  create(@Body() createRoadmapStepDetailDto: CreateRoadmapStepDetailDto) {
    return this.roadmapStepDetailService.create(createRoadmapStepDetailDto);
  }

  @Get()
  findAll() {
    return this.roadmapStepDetailService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.roadmapStepDetailService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateRoadmapStepDetailDto: UpdateRoadmapStepDetailDto) {
    return this.roadmapStepDetailService.update(+id, updateRoadmapStepDetailDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.roadmapStepDetailService.remove(+id);
  }
}
