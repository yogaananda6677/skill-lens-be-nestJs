import { Module } from '@nestjs/common';
import { RoadmapStepDetailService } from './roadmap_step_detail.service';
import { RoadmapStepDetailController } from './roadmap_step_detail.controller';

@Module({
  controllers: [RoadmapStepDetailController],
  providers: [RoadmapStepDetailService],
})
export class RoadmapStepDetailModule {}
