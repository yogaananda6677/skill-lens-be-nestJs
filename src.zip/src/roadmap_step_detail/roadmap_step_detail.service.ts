import { Injectable } from '@nestjs/common';
import { CreateRoadmapStepDetailDto } from './dto/create-roadmap_step_detail.dto';
import { UpdateRoadmapStepDetailDto } from './dto/update-roadmap_step_detail.dto';

@Injectable()
export class RoadmapStepDetailService {
  create(createRoadmapStepDetailDto: CreateRoadmapStepDetailDto) {
    return 'This action adds a new roadmapStepDetail';
  }

  findAll() {
    return `This action returns all roadmapStepDetail`;
  }

  findOne(id: number) {
    return `This action returns a #${id} roadmapStepDetail`;
  }

  update(id: number, updateRoadmapStepDetailDto: UpdateRoadmapStepDetailDto) {
    return `This action updates a #${id} roadmapStepDetail`;
  }

  remove(id: number) {
    return `This action removes a #${id} roadmapStepDetail`;
  }
}
