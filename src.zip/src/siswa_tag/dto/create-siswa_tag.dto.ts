export class CreateSiswaTagDto {}
