import { Controller, Get, Param, Put } from '@nestjs/common';
import { AdminService } from './admin.service';

@Controller('admin')
export class AdminController {
  constructor(private adminService: AdminService) {}

  @Get('dashboard')
  dashboard() {
    return this.adminService.dashboard();
  }

  @Get('verifikasi')
  verifications() {
    return this.adminService.verifications();
  }

  @Put('verifikasi/:id')
  verifikasi(@Param('id') id: number) {
    return this.adminService.verifikasiSekolah(Number(id));
  }
}
