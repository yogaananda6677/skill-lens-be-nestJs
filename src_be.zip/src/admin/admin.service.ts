import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Sekolah } from '../sekolah/entities/sekolah.entity';
import { User } from '../user/entities/user.entity';
import { Siswa } from '../siswa/entities/siswa.entity';

@Injectable()
export class AdminService {
  constructor(
    @InjectRepository(Sekolah) private sekolahRepo: Repository<Sekolah>,
    @InjectRepository(User) private userRepo: Repository<User>,
    @InjectRepository(Siswa) private siswaRepo: Repository<Siswa>,
  ) {}

  async verifikasiSekolah(id: number) {
    await this.sekolahRepo.update(id, { status_verifikasi: 'approved' });
    return { message: 'Sekolah berhasil diverifikasi' };
  }

  async dashboard() {
    const [schools, pendingSchools, teachers, students] = await Promise.all([
      this.sekolahRepo.count(),
      this.sekolahRepo.count({ where: { status_verifikasi: 'pending' } }),
      this.userRepo.count({ where: { role: 'guru' } }),
      this.siswaRepo.count(),
    ]);
    return {
      stats: { schools, pendingSchools, teachers, students },
      activities: [
        { title: 'Sinkronisasi database', text: 'Dashboard membaca data langsung dari MySQL melalui NestJS.', tone: 'info' },
        { title: 'Verifikasi sekolah', text: `${pendingSchools} sekolah masih menunggu verifikasi.`, tone: pendingSchools ? 'warning' : 'success' },
      ],
    };
  }

  async verifications() {
    const rows = await this.sekolahRepo.find({ order: { id_sekolah: 'DESC' } });
    return rows.map((row) => ({
      id: row.id_sekolah,
      school: row.nama_sekolah,
      level: row.jenis_sekolah ?? '-',
      city: row.alamat?.split(',').pop()?.trim() ?? '-',
      status: row.status_verifikasi,
      address: row.alamat ?? '-',
      phone: row.no_hp_sekolah ?? '-',
    }));
  }
}
