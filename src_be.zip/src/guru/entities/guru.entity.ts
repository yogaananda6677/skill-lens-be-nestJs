import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn
} from 'typeorm';

import { User } from '../../user/entities/user.entity';
import { Sekolah } from '../../sekolah/entities/sekolah.entity';

@Entity('guru')
export class Guru {

  @PrimaryGeneratedColumn()
  id_guru!: number;

  @Column()
  nip!: string;

 @Column({ nullable: true })
id_sekolah!: number | null;

  @ManyToOne(() => Sekolah, { nullable: true })
  @JoinColumn({ name: 'id_sekolah' })
  sekolah!: Sekolah | null;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'id_user' })
  user!: User;
}