import { Controller, Get } from '@nestjs/common';
import { GuruService } from './guru.service';

@Controller('guru')
export class GuruController {
  constructor(private readonly guruService: GuruService) {}

  @Get('guidance-cases')
  getGuidanceCases() {
    return this.guruService.getGuidanceCases();
  }
}
