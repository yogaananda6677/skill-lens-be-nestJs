import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Siswa } from '../siswa/entities/siswa.entity';
import { NilaiKategoriSiswa } from '../nilai_siswa/entities/nilai_kategori_siswa.entity';

@Injectable()
export class GuruService {
  constructor(
    @InjectRepository(Siswa) private readonly siswaRepo: Repository<Siswa>,
    @InjectRepository(NilaiKategoriSiswa) private readonly kategoriRepo: Repository<NilaiKategoriSiswa>,
  ) {}

  async getGuidanceCases() {
    const siswa = await this.siswaRepo.find({ relations: ['user'], take: 30, order: { id_siswa: 'DESC' } });
    const cases = [] as any[];
    for (const item of siswa) {
      const nilai = await this.kategoriRepo.find({ where: { id_siswa: item.id_siswa } });
      const avg = nilai.length ? Math.round(nilai.reduce((sum, row) => sum + Number(row.nilai || 0), 0) / nilai.length) : 0;
      const priority = avg && avg < 75 ? 'Tinggi' : avg < 85 ? 'Sedang' : 'Normal';
      cases.push({
        id: `g-${item.id_siswa}`,
        studentId: String(item.id_siswa),
        studentName: item.user?.nama ?? item.nisn,
        className: item.kelas,
        topic: avg ? 'Tindak lanjut rekomendasi karier berdasarkan nilai akademik' : 'Lengkapi data akademik dan minat siswa',
        priority,
        status: 'Menunggu',
        requestedAt: new Date().toLocaleDateString('id-ID'),
        schedule: 'Belum dijadwalkan',
        recommendation: avg >= 85 ? 'Karier berbasis teknologi/data' : avg >= 75 ? 'Eksplorasi minat dan portofolio' : 'Pendampingan akademik dasar',
        lastNote: avg ? `Rata-rata kategori akademik ${avg}. Perlu validasi minat, bakat, dan tujuan siswa.` : 'Data nilai belum lengkap.',
        progress: Math.max(10, Math.min(95, avg || 20)),
      });
    }
    return cases;
  }
}
