import { Controller, Get, Query } from '@nestjs/common';
import { JurusanService } from './jurusan.service';

@Controller('jurusan')
export class JurusanController {
  constructor(private readonly jurusanService: JurusanService) {}

  @Get()
  findAll(@Query('sekolahId') sekolahId?: string) {
    return this.jurusanService.findAll(sekolahId ? Number(sekolahId) : undefined);
  }
}
