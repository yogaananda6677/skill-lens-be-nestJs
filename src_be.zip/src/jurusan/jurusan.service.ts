import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Jurusan } from './entities/jurusan.entity';

@Injectable()
export class JurusanService {
  constructor(@InjectRepository(Jurusan) private readonly jurusanRepo: Repository<Jurusan>) {}

  async findAll(sekolahId?: number) {
    const where = sekolahId ? { sekolah: { id_sekolah: sekolahId } as any } : undefined;
    const rows = await this.jurusanRepo.find({ where, relations: ['sekolah'], order: { id_jurusan: 'ASC' } });
    return rows.map((row) => ({
      id: String(row.id_jurusan),
      backendId: row.id_jurusan,
      name: row.nama_jurusan,
      schoolId: row.sekolah?.id_sekolah ?? null,
    }));
  }
}
