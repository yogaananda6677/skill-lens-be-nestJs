import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Sekolah } from './entities/sekolah.entity';

export type SchoolResponse = {
  id: string;
  backendId: number;
  name: string;
  level: string;
  city: string;
  accreditation: string;
  address: string;
  totalStudents: number;
  status: string;
};

@Injectable()
export class SekolahService {
  constructor(@InjectRepository(Sekolah) private readonly sekolahRepo: Repository<Sekolah>) {}

  async findAll(): Promise<SchoolResponse[]> {
    const rows = await this.sekolahRepo.find({ order: { id_sekolah: 'ASC' } });
    return rows.map((row) => ({
      id: String(row.id_sekolah),
      backendId: row.id_sekolah,
      name: row.nama_sekolah,
      level: row.jenis_sekolah ?? '-',
      city: this.extractCity(row.alamat),
      accreditation: row.status_verifikasi === 'approved' ? 'Terverifikasi' : 'Menunggu',
      address: row.alamat ?? '-',
      totalStudents: 0,
      status: row.status_verifikasi,
    }));
  }

  private extractCity(address?: string | null) {
    if (!address) return '-';
    const parts = address.split(',').map((item) => item.trim()).filter(Boolean);
    return parts.at(-1) ?? '-';
  }
}
