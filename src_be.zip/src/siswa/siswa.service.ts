import { BadRequestException, Injectable } from '@nestjs/common';
import * as XLSX from 'xlsx';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../user/entities/user.entity';
import { Siswa } from './entities/siswa.entity';
import * as bcrypt from 'bcrypt';

function normalizeKey(value: unknown): string {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[()\[\]{}.,:;|/\\_\-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function createUsername(nama: string, nisn: string) {
  const cleanName = normalizeKey(nama).replace(/\s/g, '');
  return `${cleanName}${String(nisn).slice(-4)}`;
}

@Injectable()
export class SiswaService {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,

    @InjectRepository(Siswa)
    private readonly siswaRepo: Repository<Siswa>,
  ) {}

  async importExcel(file: any) {
    if (!file?.buffer) {
      throw new BadRequestException('File Excel belum dikirim. Gunakan field multipart bernama file.');
    }

    const workbook = XLSX.read(file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(workbook.Sheets[sheetName], {
      defval: '',
      raw: false,
    });

    let imported = 0;
    let updated = 0;
    const accounts: Array<{ nisn: string; nama: string; username: string; password_default: string; akun_baru: boolean }> = [];

    for (const row of rows) {
      const normalizedRow = Object.entries(row).reduce((acc, [key, value]) => {
        acc[normalizeKey(key)] = value;
        return acc;
      }, {} as Record<string, any>);

      const nisn = String(normalizedRow.nisn || normalizedRow.nis || '').trim();
      const nama = String(normalizedRow.nama || normalizedRow['nama siswa'] || '').trim();
      const kelas = String(normalizedRow.kelas || '').trim() || '-';
      const jurusan = String(normalizedRow.jurusan || normalizedRow['program keahlian'] || normalizedRow['kompetensi keahlian'] || '').trim() || '-';

      if (!nisn || !nama) continue;

      let siswa = await this.siswaRepo.findOne({ where: { nisn }, relations: ['user'] });
      let akunBaru = false;
      let username = siswa?.user?.username || '';

      if (!siswa) {
        username = await this.generateUniqueUsername(createUsername(nama, nisn));
        const password = await bcrypt.hash(nisn, 12);
        const userBaru = await this.userRepo.save({
          nama,
          email: `${nisn}@skilllens.local`,
          username,
          password,
          role: 'siswa',
        });

        siswa = await this.siswaRepo.save({
          nisn,
          kelas,
          jurusan,
          user: userBaru,
        });
        akunBaru = true;
        imported += 1;
      } else {
        siswa.kelas = kelas || siswa.kelas;
        siswa.jurusan = jurusan || siswa.jurusan;
        if (siswa.user) {
          siswa.user.nama = nama || siswa.user.nama;
          await this.userRepo.save(siswa.user);
        }
        await this.siswaRepo.save(siswa);
        updated += 1;
      }

      accounts.push({
        nisn,
        nama,
        username,
        password_default: nisn,
        akun_baru: akunBaru,
      });
    }

    return {
      message: 'Import siswa berhasil diproses',
      imported,
      updated,
      accounts,
    };
  }

  private async generateUniqueUsername(baseUsername: string) {
    const fallback = baseUsername || `siswa${Date.now()}`;
    let username = fallback;
    let index = 1;

    while (await this.userRepo.findOne({ where: { username } })) {
      username = `${fallback}${index}`;
      index += 1;
    }

    return username;
  }
}
