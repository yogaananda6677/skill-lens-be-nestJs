import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Post,
  Req,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';

import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RoleGuard } from '../auth/role';
import { UserRole } from '../user/entities/user.entity';
import { SiswaService } from '../siswa/siswa.service';
import { AdminSekolahService } from './admin_sekolah.service';
import { CreateAdminSchoolDto } from './dto/create-admin-school.dto';
import { CreateAdminTeacherDto } from './dto/create-admin-teacher.dto';
import 'multer';

@Controller('admin-sekolah')
@UseGuards(JwtAuthGuard, new RoleGuard(['admin_sekolah']))
export class AdminSekolahController {
  constructor(
    private readonly adminSekolahService: AdminSekolahService,
    private readonly siswaService: SiswaService,
  ) {}

  @Get('status')
  getStatus(@Req() req: any) {
    return this.adminSekolahService.getStatus(req.user.id);
  }

  @Post('sekolah')
  createOrUpdateSchool(
    @Req() req: any,
    @Body() dto: CreateAdminSchoolDto,
  ) {
    return this.adminSekolahService.createOrUpdateSchool(req.user.id, dto);
  }

  @Get('guru')
    listTeachers(@Req() req: any) {
    return this.adminSekolahService.listTeachers(req.user.id);
    }

  @Post('guru')
  createTeacher(
    @Req() req: any,
    @Body() dto: CreateAdminTeacherDto,
  ) {
    return this.adminSekolahService.createTeacher(req.user.id, dto);
  }

  @Get('jurusan')
listJurusan(@Req() req: any) {
  return this.adminSekolahService.listJurusan(req.user.id);
}

@Post('jurusan')
createJurusan(@Req() req: any, @Body() body: any) {
  return this.adminSekolahService.createJurusan(req.user.id, body);
}
  @Post('siswa/import')
  @UseInterceptors(FileInterceptor('file'))
  async importSiswa(
    @Req() req: any,
    @UploadedFile() file: Express.Multer.File,
  ) {
    if (!file) {
      throw new BadRequestException('File Excel siswa wajib diunggah.');
    }

    const sekolah = await this.adminSekolahService.getApprovedSchoolOrFail(
      req.user.id,
    );

    return this.siswaService.importExcel(
      file,
      {
        id_user: req.user.id,
        role: req.user.role as UserRole,
      },
      {
        id_sekolah: sekolah.id_sekolah,
      },
    );
  }
}