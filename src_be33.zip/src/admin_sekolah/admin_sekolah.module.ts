import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { AdminSekolahController } from './admin_sekolah.controller';
import { AdminSekolahService } from './admin_sekolah.service';

import { User } from '../user/entities/user.entity';
import { Guru } from '../guru/entities/guru.entity';
import { Sekolah } from '../sekolah/entities/sekolah.entity';
import { Jurusan } from '../jurusan/entities/jurusan.entity';
import { SiswaModule } from '../siswa/siswa.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([User, Guru, Sekolah, Jurusan]),
    SiswaModule,
  ],
  controllers: [AdminSekolahController],
  providers: [AdminSekolahService],
  exports: [AdminSekolahService],
})
export class AdminSekolahModule {}