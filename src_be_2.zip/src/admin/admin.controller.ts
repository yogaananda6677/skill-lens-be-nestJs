import { Body, Controller, Get, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RoleGuard } from '../auth/role';

@UseGuards(JwtAuthGuard, new RoleGuard(['superadmin', 'admin']))
@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('dashboard')
  dashboard() {
    return this.adminService.dashboard();
  }

  @Get('verifikasi')
  verifications() {
    return this.adminService.verifications();
  }

  @Put('verifikasi/:id')
  verifikasi(@Param('id') id: string) {
    return this.adminService.verifikasiSekolah(Number(id));
  }

  @Get('sekolah')
  schools() {
    return this.adminService.schools();
  }

//   @Get('jurusan')
//   majors(@Query('sekolahId') sekolahId?: string) {
//     return this.adminService.majors(sekolahId ? Number(sekolahId) : undefined);
//   }

//   @Post('jurusan')
//   createMajor(@Body() body: any) {
//     return this.adminService.createMajor(body);
//   }
}
