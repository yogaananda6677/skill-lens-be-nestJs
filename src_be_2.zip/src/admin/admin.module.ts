import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { AdminService } from './admin.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';
import { Sekolah } from 'src/sekolah/entities/sekolah.entity';
import { Siswa } from 'src/siswa/entities/siswa.entity';
import { Jurusan } from 'src/jurusan/entities/jurusan.entity';

@Module({
  controllers: [AdminController],
  providers: [AdminService],
  imports: [TypeOrmModule.forFeature([User, Sekolah, Siswa, Jurusan])],
})
export class AdminModule {}