import { IsEmail, IsNotEmpty, IsOptional, MinLength } from 'class-validator';

export class CreateAdminDto {
  @IsNotEmpty()
  nama!: string;

  @IsEmail()
  email!: string;

  @IsNotEmpty()
  username!: string;

  @IsOptional()
  no_hp?: string;

  @MinLength(6)
  password!: string;
}