import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { GuruService } from './guru.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RoleGuard } from '../auth/role';

@UseGuards(JwtAuthGuard, new RoleGuard(['guru']))
@Controller('guru')
export class GuruController {
  constructor(private readonly guruService: GuruService) {}

  @Get('workspace')
  getWorkspace(@Req() req: any) {
    return this.guruService.getWorkspace(req.user.id_user);
  }

  @Post('pilih-sekolah')
  chooseSchool(@Req() req: any, @Body() body: any) {
    return this.guruService.chooseSchool(req.user.id_user, body);
  }

  @Post('ajukan-sekolah')
  requestNewSchool(@Req() req: any, @Body() body: any) {
    return this.guruService.requestNewSchool(req.user.id_user, body);
  }

  @Get('guidance-cases')
  getGuidanceCases(@Req() req: any) {
    return this.guruService.getGuidanceCases(req.user.id_user);
  }
}
