import {
  BadGatewayException,
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';

type RawSchool = Record<string, any>;

@Injectable()
export class SchoolLookupService {
  private readonly apiUrl =
    process.env.SCHOOL_LOOKUP_API_URL ||
    'https://api.fazriansyah.eu.org/v1/sekolah';

  private readonly allowedTypes = [
    'SMA',
    'SMK',
    'MA',
    'MAK',
    'PAKET C',
    'PKBM',
    'SKB',
  ];

  async findByNpsn(npsn: string) {
    const cleanNpsn = String(npsn || '').trim();

    if (!/^\d{8}$/.test(cleanNpsn)) {
      throw new BadRequestException('NPSN harus berisi 8 digit angka.');
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    try {
      const response = await fetch(
        `${this.apiUrl}?npsn=${encodeURIComponent(cleanNpsn)}`,
        {
          method: 'GET',
          signal: controller.signal,
          headers: {
            Accept: 'application/json',
          },
        },
      );

      if (!response.ok) {
        throw new BadGatewayException(
          'Gagal mengambil data sekolah dari API eksternal.',
        );
      }

      const json = await response.json();
      const school = this.resolveSchoolObject(json);

      if (!school) {
        throw new NotFoundException('Data sekolah tidak ditemukan.');
      }

      const normalized = this.normalizeSchool(school);

      if (!normalized.npsn || !normalized.nama_sekolah) {
        throw new NotFoundException('Data sekolah tidak lengkap.');
      }

      if (!this.isAllowedSchoolType(normalized.jenis_sekolah)) {
        throw new BadRequestException(
          `Sekolah ${normalized.nama_sekolah} bukan SMA/SMK/sederajat.`,
        );
      }

      return {
        success: true,
        message: 'Data sekolah berhasil ditemukan.',
        data: normalized,
      };
    } catch (error) {
      if (
        error instanceof BadRequestException ||
        error instanceof NotFoundException ||
        error instanceof BadGatewayException
      ) {
        throw error;
      }

      throw new BadGatewayException(
        'API data sekolah sedang tidak bisa diakses. Coba lagi nanti.',
      );
    } finally {
      clearTimeout(timeout);
    }
  }

  private resolveSchoolObject(json: any): RawSchool | null {
    return (
      json?.data?.satuanPendidikan ||
      json?.satuanPendidikan ||
      json?.data ||
      json ||
      null
    );
  }

  private normalizeSchool(school: RawSchool) {
    const npsn = this.pick(school, ['npsn', 'NPSN']);
    const namaSekolah = this.pick(school, [
      'nama',
      'sekolah',
      'namaSekolah',
      'nama_satuan_pendidikan',
      'namaSatuanPendidikan',
    ]);

    const jenisSekolah = this.normalizeType(
      this.pick(school, [
        'bentuk',
        'bentukPendidikan',
        'bentuk_pendidikan',
        'jenisSekolah',
        'jenis_sekolah',
      ]),
      namaSekolah,
    );

    const statusSekolah = this.normalizeStatus(
      this.pick(school, [
        'status',
        'statusSatuanPendidikan',
        'statusSekolah',
        'status_sekolah',
      ]),
    );

    const alamatJalan = this.pick(school, [
      'alamatJalan',
      'alamat_jalan',
      'alamat',
    ]);

    const desa = this.pick(school, [
      'namaDesa',
      'desa',
      'desaKelurahan',
      'kelurahan',
      'namaDesaKelurahan',
    ]);

    const kecamatan = this.pick(school, [
      'namaKecamatan',
      'kecamatan',
      'kecamatanKota',
    ]);

    const kabupatenKota = this.pick(school, [
      'namaKabupaten',
      'namaKabupatenKota',
      'kabupaten',
      'kabupatenKota',
      'kabupaten_kota',
    ]);

    const provinsi = this.pick(school, [
      'namaProvinsi',
      'provinsi',
      'propinsi',
    ]);

    const alamatSekolah = [
      alamatJalan,
      desa,
      kecamatan,
      kabupatenKota,
      provinsi,
    ]
      .filter(Boolean)
      .join(', ');

    return {
      npsn,
      nama_sekolah: namaSekolah,
      jenis_sekolah: jenisSekolah,
      status_sekolah: statusSekolah,
      no_hp_sekolah: this.pick(school, [
        'telepon',
        'telp',
        'noTelepon',
        'no_hp',
        'noHp',
      ]),
      email_sekolah: this.pick(school, ['email', 'emailSekolah']),
      alamat_sekolah: alamatSekolah,
      desa,
      kecamatan,
      kabupaten_kota: kabupatenKota,
      provinsi,
      akreditasi: this.pick(school, ['akreditasi']),
      sumber: 'api.fazriansyah.eu.org',
    };
  }

  private pick(source: RawSchool, keys: string[]) {
    for (const key of keys) {
      const value = source?.[key];

      if (value !== undefined && value !== null && String(value).trim()) {
        return String(value).trim();
      }
    }

    return null;
  }

  private normalizeStatus(value: string | null) {
    if (!value) return null;

    const upper = value.toUpperCase();

    if (upper === 'N') return 'NEGERI';
    if (upper === 'S') return 'SWASTA';

    return upper;
  }

  private normalizeType(value: string | null, namaSekolah: string | null) {
    const raw = `${value || ''} ${namaSekolah || ''}`.toUpperCase();

    if (raw.includes('SMK')) return 'SMK';
    if (raw.includes('SMA')) return 'SMA';
    if (raw.includes('MAK')) return 'MAK';
    if (raw.includes('MA ')) return 'MA';
    if (raw.includes('PAKET C')) return 'PAKET C';
    if (raw.includes('PKBM')) return 'PKBM';
    if (raw.includes('SKB')) return 'SKB';

    return value ? value.toUpperCase() : null;
  }

  private isAllowedSchoolType(type: string | null) {
    if (!type) return false;

    const upper = type.toUpperCase();

    return this.allowedTypes.some((allowed) => upper.includes(allowed));
  }
}