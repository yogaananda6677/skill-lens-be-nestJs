export class CreatePrestasiSiswaDto {}
