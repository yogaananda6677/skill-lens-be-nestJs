import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { PrestasiSiswaService } from './prestasi_siswa.service';
import { CreatePrestasiSiswaDto } from './dto/create-prestasi_siswa.dto';
import { UpdatePrestasiSiswaDto } from './dto/update-prestasi_siswa.dto';

@Controller('prestasi-siswa')
export class PrestasiSiswaController {
  constructor(private readonly prestasiSiswaService: PrestasiSiswaService) {}

  @Post()
  create(@Body() createPrestasiSiswaDto: CreatePrestasiSiswaDto) {
    return this.prestasiSiswaService.create(createPrestasiSiswaDto);
  }

  @Get()
  findAll() {
    return this.prestasiSiswaService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.prestasiSiswaService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updatePrestasiSiswaDto: UpdatePrestasiSiswaDto) {
    return this.prestasiSiswaService.update(+id, updatePrestasiSiswaDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.prestasiSiswaService.remove(+id);
  }
}
