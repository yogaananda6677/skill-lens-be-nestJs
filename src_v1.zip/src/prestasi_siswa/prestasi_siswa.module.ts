import { Module } from '@nestjs/common';
import { PrestasiSiswaService } from './prestasi_siswa.service';
import { PrestasiSiswaController } from './prestasi_siswa.controller';

@Module({
  controllers: [PrestasiSiswaController],
  providers: [PrestasiSiswaService],
})
export class PrestasiSiswaModule {}
