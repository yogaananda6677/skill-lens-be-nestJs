import { Injectable } from '@nestjs/common';
import { CreatePrestasiSiswaDto } from './dto/create-prestasi_siswa.dto';
import { UpdatePrestasiSiswaDto } from './dto/update-prestasi_siswa.dto';

@Injectable()
export class PrestasiSiswaService {
  create(createPrestasiSiswaDto: CreatePrestasiSiswaDto) {
    return 'This action adds a new prestasiSiswa';
  }

  findAll() {
    return `This action returns all prestasiSiswa`;
  }

  findOne(id: number) {
    return `This action returns a #${id} prestasiSiswa`;
  }

  update(id: number, updatePrestasiSiswaDto: UpdatePrestasiSiswaDto) {
    return `This action updates a #${id} prestasiSiswa`;
  }

  remove(id: number) {
    return `This action removes a #${id} prestasiSiswa`;
  }
}
